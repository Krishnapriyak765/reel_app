import 'package:flutter/material.dart';

class HomeUploadPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: Text('Upload Your Video')),
    );
  }
}