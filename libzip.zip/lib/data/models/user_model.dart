class UserModel {
  final String name;
  UserModel({required this.name});
}