import 'package:go_router/go_router.dart';
import 'package:winngoo_reels_app/presentation/pages/auth/register/register_page.dart';
import 'package:winngoo_reels_app/presentation/pages/competition/competition_page.dart';

final GoRouter router = GoRouter(
  routes: [
    GoRoute(
      path: '/',
      name: 'competition',
      builder: (context, state) => CompetitionPage(),
    ),
    GoRoute(
      path: '/register',
      name: 'register',
      builder: (context, state) => RegisterPage(),
    ),
  ],
);
